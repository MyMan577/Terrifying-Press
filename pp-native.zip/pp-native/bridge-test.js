const { JSDOM } = require('jsdom');
const fs = require('fs');
const code = fs.readFileSync('/home/claude/pp-native/www/native-bridge.js','utf8');

function makeEnv(){
  const dom = new JSDOM('<!doctype html><body><audio id="audio"></audio><video id="video-el"></video></body>', { url: 'https://localhost/', runScripts: 'outside-only', pretendToBeVisual: true });
  const w = dom.window;
  const listeners = {};
  const calls = [];
  const mk = (name) => new Proxy({}, { get: (_, m) => {
    if (m === 'addListener') return (ev, cb) => { (listeners[name+':'+ev] = listeners[name+':'+ev] || []).push(cb); return Promise.resolve({remove(){}}); };
    return (args) => { calls.push([name, m, args]); return Promise.resolve(fake(name, m, args)); };
  }});
  let curUri = null, written = {};
  function fake(name, m, a){
    if (name==='PPPlayer' && m==='loadMedia') curUri = a.uri;
    if (name==='PPPlayer' && m==='getState') return { uri: curUri, playing:true, playWhenReady:true, state:'ready', posMs:0, durMs:180000, rate:1 };
    if (name==='PPLibrary' && m==='writeChunk'){ written[a.name] = (written[a.name]||0) + Buffer.from(a.base64,'base64').length; return { uri:'file:///data/media/'+a.name, size: written[a.name] }; }
    return {};
  }
  w.Capacitor = { isNativePlatform: () => true, getPlatform: () => 'android', convertFileSrc: (x)=>x,
    Plugins: { PPPlayer: mk('PPPlayer'), PPLibrary: mk('PPLibrary'), PPJobs: mk('PPJobs') } };
  w.localStorage.clear();
  w.eval(code);
  const fire = (plug, ev, data) => (listeners[plug+':'+ev]||[]).forEach(cb => cb(data));
  return { w, calls, fire, setCur: (u)=>{curUri=u;} };
}
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
let fails = 0;
const ok = (c, msg) => { if (!c) { fails++; console.log('FAIL:', msg); } else console.log('ok  :', msg); };

(async () => {
  // ---- 1. basic native audio track ----
  let { w, calls, fire, setCur } = makeEnv();
  const N = w.PPNative;
  ok(N.available && N.enabled, 'bridge activates on android + plugins');
  const A = N.wrapMedia(w.document.getElementById('audio'), 'audio');
  ok(w.document.getElementById('audio') === A, 'getElementById returns facade for other scripts');
  const evs = [];
  ['loadstart','loadedmetadata','canplay','play','playing','pause','ended','timeupdate','seeking','seeked','durationchange'].forEach(t =>
    A.addEventListener(t, (e) => evs.push(t + (e.target === A ? '' : '!target'))));
  const t1 = { dbId:'n_1', kind:'audio', nativeUri:'content://x/1', url:'', title:'One', artist:'Me', ext:'mp3' };
  await N.setSrc(A, t1);
  ok(calls.some(c => c[1]==='loadMedia' && c[2].uri==='content://x/1' && c[2].title==='One'), 'loadMedia sent with metadata');
  ok(A.paused === true && isNaN(A.duration), 'paused / NaN duration before ready');
  fire('PPPlayer','state',{ uri:'content://x/1', state:'ready', playing:false, playWhenReady:false, posMs:0, durMs:200000, rate:1, why:'state' });
  ok(A.duration === 200 && A.readyState === 4, 'duration + readyState after ready');
  ok(['loadedmetadata','canplay','durationchange'].every(e => evs.includes(e)), 'metadata events dispatched');
  ok(!evs.some(e => e.includes('!target')), 'event.target is the facade (app compares e.target === media())');
  const p = A.play(); ok(p && typeof p.then === 'function', 'play() returns a promise');
  await p;
  ok(calls.some(c => c[1]==='play'), 'play forwarded to native');
  ok(evs.includes('play'), "'play' event fired");
  fire('PPPlayer','state',{ uri:'content://x/1', state:'ready', playing:true, playWhenReady:true, posMs:1000, durMs:200000, rate:1, why:'playing' });
  ok(evs.includes('playing') && A.paused === false, "'playing' + paused=false");
  // stale snapshot from previous item must be ignored
  fire('PPPlayer','state',{ uri:'content://OLD', state:'ended', playing:false, playWhenReady:false, posMs:0, durMs:1, rate:1 });
  ok(A.ended === false, 'stale snapshot (other uri) ignored');
  // local pause then late "playing" snapshot must not flip back
  A.pause();
  fire('PPPlayer','state',{ uri:'content://x/1', state:'ready', playing:true, playWhenReady:true, posMs:1200, durMs:200000, rate:1, why:'playing' });
  ok(A.paused === true, 'late snapshot does not undo a local pause');
  await sleep(700);
  // speed / volume / seek
  A.playbackRate = 1.5; A.volume = 0.4; A.currentTime = 42;
  await sleep(10);
  ok(calls.some(c => c[1]==='setRate' && c[2].rate===1.5), 'playbackRate -> setRate');
  ok(calls.some(c => c[1]==='setVolume' && Math.abs(c[2].volume-0.4)<1e-6), 'volume -> setVolume');
  ok(calls.some(c => c[1]==='seek' && c[2].ms===42000), 'currentTime= -> seek(ms)');
  ok(A.seeking === true && Math.abs(A.currentTime - 42) < 0.05, 'seeking + optimistic currentTime');
  fire('PPPlayer','state',{ uri:'content://x/1', state:'ready', playing:false, playWhenReady:false, posMs:42000, durMs:200000, rate:1.5, why:'seeked' });
  ok(A.seeking === false && evs.includes('seeked'), "'seeked' after native confirms");
  // external pause from notification
  A.play(); await sleep(700);
  evs.length = 0;
  fire('PPPlayer','state',{ uri:'content://x/1', state:'ready', playing:true, playWhenReady:true, posMs:43000, durMs:200000, rate:1.5, why:'playing' });
  fire('PPPlayer','state',{ uri:'content://x/1', state:'ready', playing:false, playWhenReady:false, posMs:44000, durMs:200000, rate:1.5, why:'playing' });
  ok(A.paused === true, 'external pause (notification/headset) reflected');

  // ---- 2. native auto-advance + adoption ----
  const t2 = { dbId:'n_2', kind:'audio', nativeUri:'content://x/2', url:'', title:'Two' };
  evs.length = 0; calls.length = 0;
  N.queueNext(t2); await sleep(20);
  ok(calls.some(c => c[1]==='setNext' && c[2].uri==='content://x/2'), 'queueNext -> setNext(uri)');
  setCur('content://x/2');   // the fake native player is now on item 2
  fire('PPPlayer','advanced',{ uri:'content://x/2', playing:true, playWhenReady:true, state:'ready', posMs:0, durMs:90000, rate:1 });
  ok(evs.includes('ended'), "'ended' dispatched so the app runs its normal next-track logic");
  calls.length = 0;
  A.pause();                       // loadTrack() begins by pausing; must be ignored while adopting
  ok(!calls.some(c => c[1]==='pause'), 'pause during adoption does not interrupt native playback');
  await N.setSrc(A, t2);
  ok(!calls.some(c => c[1]==='loadMedia'), 'setSrc adopts the already-playing item (no reload)');
  console.log('   adopted ->', A.duration, A.paused, A.__pp.ready);
  ok(A.duration === 180 && A.paused === false && A.__pp.ready, 'adopted state taken from native snapshot (duration, playing, ready)');

  // ---- 3. legacy IndexedDB blob is moved to disk, then played natively ----
  ({ w, calls, fire } = makeEnv());
  const N3 = w.PPNative;
  const V = N3.wrapMedia(w.document.getElementById('video-el'), 'video');
  const blob = new w.Blob([Buffer.alloc(5*1024*1024, 7)], { type:'video/mp4' });
  let migrated = null, blobFreed = false;
  N3.hooks.getBlob = async () => blob;
  N3.hooks.onMigrated = (t) => { migrated = t.nativeUri; blobFreed = true; };
  const t3 = { dbId:'m_9', kind:'video', url:'blob:legacy', title:'Old', ext:'mp4' };
  await N3.setSrc(V, t3);
  ok(calls.filter(c => c[1]==='writeChunk').length === 2, 'blob streamed in 3MB chunks (2 chunks for 5MB)');
  ok(migrated === 'file:///data/media/m_9.mp4' && t3.nativeUri === migrated && t3.nativeLocal, 'track migrated: nativeUri + nativeLocal set');
  ok(blobFreed, 'IndexedDB copy released only after size verified');
  ok(calls.some(c => c[1]==='loadMedia' && c[2].uri===migrated), 'native loads the migrated file');
  ok(calls.some(c => c[1]==='setVideoRect') === false, 'no rect before layout (jsdom has none) - ok');
  // failing copy falls back to web engine
  ({ w, calls, fire } = makeEnv());
  const N4 = w.PPNative;
  const V4 = N4.wrapMedia(w.document.getElementById('video-el'), 'video');
  N4.hooks.getBlob = async () => { throw new Error('boom'); };
  const t4 = { dbId:'m_10', kind:'video', url:'blob:legacy2', title:'Bad' };
  await N4.setSrc(V4, t4);
  await sleep(20);
  ok(V4.__pp.active === false && V4.src.endsWith('blob:legacy2'), 'migration failure falls back to the web element');
  ok(calls.some(c => c[1]==='stop'), 'native player stopped on fallback');

  // ---- 5. video filters: CSS chain -> ordered GPU ops ----
  ({ w, calls, fire } = makeEnv());
  const N5 = w.PPNative;
  w.document.body.insertAdjacentHTML('beforeend',
    '<svg><feFuncR id="posterize-r" tableValues="0 0.333 0.667 1"/>' +
    '<feFuncR id="duotone-r" tableValues="0.1 0.9"/><feFuncG id="duotone-g" tableValues="0.2 0.8"/><feFuncB id="duotone-b" tableValues="0.3 0.7"/>' +
    '<feConvolveMatrix id="sharpen-matrix" kernelMatrix="0 -0.6 0 -0.6 3.4 -0.6 0 -0.6 0"/>' +
    '<feComposite id="clarity-boost" k2="0.7"/></svg>');
  const V5 = N5.wrapMedia(w.document.getElementById('video-el'), 'video');
  await N5.setSrc(V5, { dbId:'v1', kind:'video', nativeUri:'content://v/1', url:'', title:'Clip' });
  const lastOps = () => { const c = calls.filter(x => x[1]==='setVideoFilter').pop(); return c ? c[2].ops : null; };
  const group = (flat) => { const o=[]; for (let i=0;i<flat.length;i+=8) o.push(flat.slice(i,i+8)); return o; };
  calls.length = 0;
  N5.setVideoFilterCss('saturate(1.70) contrast(1.12) brightness(1.03) sepia(0.00) grayscale(0.00) hue-rotate(0.0deg) invert(0.00)');
  await sleep(5);
  let g = group(lastOps() || []);
  ok(g.length === 3 && g[0][0]===2 && g[0][1]===1.7 && g[1][0]===1 && g[2][0]===0, 'preset -> saturate, contrast, brightness in CSS order; identity ops dropped');
  calls.length = 0;
  N5.setVideoFilterCss('saturate(1.70) contrast(1.12) brightness(1.03) sepia(0.00) grayscale(0.00) hue-rotate(0.0deg) invert(0.00)');
  await sleep(5);
  ok(!calls.some(x => x[1]==='setVideoFilter'), 'unchanged filter is not re-sent');
  calls.length = 0;
  N5.setVideoFilterCss('sepia(0.75) hue-rotate(90deg) invert(0.5) url(#posterize-filter) brightness(110%)');
  await sleep(5);
  g = group(lastOps());
  ok(g.map(o=>o[0]).join() === '3,5,6,7,0', 'sepia, hue-rotate, invert, posterize, brightness% keep their order');
  ok(Math.abs(g[1][1]) < 1e-6 && Math.abs(g[1][2]-1) < 1e-6, 'hue-rotate(90deg) -> cos 0, sin 1');
  ok(g[3][1] === 4, 'posterize level count read from the page SVG table (4)');
  ok(Math.abs(g[4][1]-1.1) < 1e-9, 'percent values normalised (110% -> 1.1)');
  calls.length = 0;
  N5.setVideoFilterCss('url(#duotone-filter) url(#sharpen-filter) url(#clarity-filter)');
  await sleep(5);
  g = group(lastOps());
  ok(g[0][0]===8 && g[0][1]===0.1 && g[0][2]===0.2 && g[0][3]===0.3 && g[0][4]===0.9 && g[0][5]===0.8 && g[0][6]===0.7, 'duotone dark/light colours from SVG tables');
  ok(g[1][0]===9 && g[1][1]===3.4 && g[1][2]===-0.6, 'sharpen kernel centre/edge from SVG matrix');
  ok(g[2][0]===10 && Math.abs(g[2][1]-1.4) < 1e-9, 'clarity amount = 2 x slope (page formula)');
  // slider moves SVG attribute without changing the CSS string -> still picked up
  calls.length = 0;
  w.document.getElementById('clarity-boost').setAttribute('k2', '0.2');
  N5.setVideoFilterCss('url(#duotone-filter) url(#sharpen-filter) url(#clarity-filter)');
  await sleep(5);
  ok(Math.abs(group(lastOps())[2][1]-0.4) < 1e-9, 'slider change (same CSS string) is re-sent');
  calls.length = 0;
  N5.setVideoFilterCss('none'); await sleep(5);
  ok((lastOps() || ['x']).length === 0, "'none' clears the GPU chain");

  // ---- 6. car / Assistant started something; native queue differs from the app's ----
  ({ w, calls, fire } = makeEnv());
  const N6 = w.PPNative;
  const A6 = N6.wrapMedia(w.document.getElementById('audio'), 'audio');
  let synced = null;
  N6.hooks.syncTo = (u) => { synced = u; };
  fire('PPPlayer', 'external', { uri: 'content://car/9' });
  ok(synced === 'content://car/9', "'external' (Android Auto / Assistant) reaches the app");
  // cold: nothing loaded in JS yet, then app adopts the playing item without reloading
  synced = null; calls.length = 0;
  N6.hooks.syncTo = async (u) => { N6.expectAdvance(u); await N6.setSrc(A6, { dbId:'c9', kind:'audio', nativeUri:u, url:'', title:'Car' }); };
  fire('PPPlayer', 'external', { uri: 'content://car/9' });
  await sleep(30);
  ok(!calls.some(c => c[1]==='loadMedia') && A6.__pp.active, 'externally started item is adopted, not reloaded');
  // advanced to an item the app would not choose
  const A6b = A6; const evs6 = [];
  A6b.addEventListener('ended', () => evs6.push('ended'));
  let followed = null;
  N6.hooks.matchesNext = () => false; N6.hooks.syncTo = (u) => { followed = u; };
  fire('PPPlayer', 'advanced', { uri: 'content://car/10', playing:true, playWhenReady:true, state:'ready', posMs:0, durMs:1000, rate:1 });
  ok(followed === 'content://car/10' && evs6.length === 0, 'advance to an unexpected item: app follows native, no spurious ended');

  // ---- 7. catalog for Android Auto / Assistant ----
  calls.length = 0;
  N6.pushCatalog([{ id:'a', uri:'content://x/a', title:'A' }], [{ id:'p', name:'Mix' }]);
  await sleep(5);
  const cc = calls.find(c => c[1]==='setCatalog');
  ok(cc && cc[2].items.length === 1 && cc[2].playlists[0].name === 'Mix', 'library mirrored to native catalog');

  // ---- 4. plain browser: everything inert ----
  const dom = new JSDOM('<!doctype html><body><audio id="audio"></audio></body>', { url: 'https://localhost/', runScripts:'outside-only' });
  dom.window.eval(code);
  const NB = dom.window.PPNative;
  const el = dom.window.document.getElementById('audio');
  ok(NB.available === false && NB.wrapMedia(el,'audio') === el, 'browser: no wrapping');
  await NB.setSrc(el, { url: 'blob:abc' });
  ok(el.getAttribute('src') === 'blob:abc', 'browser: setSrc sets src like before');
  console.log(fails ? `\n${fails} FAILED` : '\nALL PASSED');
  process.exit(fails ? 1 : 0);
})().catch(e => { console.error('ERR', e && (e.stack || e.message || String(e)), e && e.name); process.exit(2); });
