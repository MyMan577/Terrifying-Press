# Press Play: native Android layer

Moves playback, files, video, filters and background work off the WebView and onto Android APIs, and
registers Press Play as a real media app. Your HTML UI stays; the engine under it changes. In a normal browser,
or if the native code isn't installed, the app runs exactly as before.

> **Status: written but not compiled or run on a device.** I had no Android toolchain here.
> What *has* been checked: the JS bridge (48 automated assertions, below), both GLSL shaders (compiled with
> `glslangValidator` as GLSL ES 1.00), and all inline scripts in the patched HTML (`node --check`).
> The Kotlin was reviewed by hand only. Expect a few compile fixes on first build, mostly Media3 API drift
> (versions are pinned to reduce that).

## What you get

| Area | Before | Now |
|---|---|---|
| Recognised as a media app | none | `MediaLibraryService` + manifest declarations (see below): system media notification, lock screen, Bluetooth/car kits, Android Auto, Wear, Assistant, "Open with", default-music-app slots |
| Background audio | WebView element + a fragile hand-off trick | Foreground service + ExoPlayer: audio focus, pause on unplug, survives the screen turning off |
| Track changes with screen off | JS `ended` handler (can be throttled) | ExoPlayer plays the queued next item itself (gapless); JS re-syncs when it wakes |
| Video | `<video>` via the page compositor | MediaCodec to a `SurfaceView` under a transparent WebView; HTML controls/subtitles draw on top. Frame-rate matching, HEVC/AV1/10-bit/MKV, embedded audio/subtitle tracks |
| **Video filters** | CSS + SVG filters on the page | **One GPU shader** runs the same chain: presets (saturate/contrast/brightness/sepia/grayscale/hue-rotate/invert), auto-levels, posterize, duotone, sharpen, clarity, and the Adjust sliders. Sliders update live without rebuilding the pipeline |
| Snapshots | `drawImage(video)` | Read back from the native surface (filters included) |
| Effects | Web Audio graph | Native 10-band EQ, boost, bass, DJ filter, distortion, bitcrush, tremolo, echo, reverb |
| Visualizer | AnalyserNode | Same canvas code, fed by a native FFT (no mic permission) |
| Library | Blobs copied into IndexedDB | SAF references with persisted access. Legacy blobs move to app storage on first play; the IndexedDB copy is deleted after a size check |
| Folder import | `<input webkitdirectory>` | System picker, recursive scan, tags/art/duration, sidecar `.lrc`/`.srt`/`.vtt`, re-scan on launch |
| Saving | Share sheet | Straight into `Music/Press Play` or `Movies/Press Play` (Android 10+), share sheet as fallback |
| Android extras | none | Picture-in-Picture, screen-on during video, notification permission, background-task notifications |

## How Android now sees the app as a media player

| Signal | Where | Effect |
|---|---|---|
| `MediaLibraryService` with the `MediaBrowserService` action | `PlaybackService`, manifest | Discoverable and browsable by Android Auto, car kits, Wear, Assistant, system media controls, even with the UI closed |
| Browsable catalog (Songs / Playlists / Artists / Videos) | `Catalog.kt`, pushed from the page, saved to disk | Car/Assistant can list and play your library after a cold start |
| Voice | `onAddMediaItems` (session) + `MEDIA_PLAY_FROM_SEARCH` (activity) + page-side search | "Play <title/artist> on Press Play" |
| `MediaButtonReceiver` + `onPlaybackResumption` | manifest, `PlaybackService` | Headset / Bluetooth play button resumes the last item even when the app isn't running |
| `APP_MUSIC` / `MUSIC_PLAYER` intent filters, `android:appCategory="audio"` | manifest | Counts as a music app for launchers, default-app pickers and usage grouping |
| `VIEW` for audio/video (content, file, http, https), playlists, Ogg/Matroska MIME types; `SEND`/`SEND_MULTIPLE` | manifest | Appears in "Open with" and the share sheet |
| `automotive_app_desc.xml` | manifest meta-data | Listed in Android Auto's media apps |

## Install (about 10 minutes)

1. Copy `android/app/src/main/java/com/pressplay/media/*.kt` into your project's `app/src/main/java/com/pressplay/media/`.
2. Merge `AndroidManifest.xml` (permissions, `appCategory`, activity filters, services, receiver, Auto meta-data).
   Copy `res/xml/*` and `res/values/pp_strings.xml`.
3. Apply `app/build.gradle.additions.txt` (Kotlin plugin, Media3 **1.4.1**, `minSdk 26`).
   Capacitor projects are Java-only by default, so you need the Kotlin plugin.
4. Replace `www/index.html` with the patched one; add `www/native-bridge.js` next to it.
5. `npx cap sync android`, then build.

`MainActivity.kt` replaces Capacitor's default one (registers the three plugins and installs the video layer).
Keep your existing Capacitor `Filesystem`/`Share` plugins; exports still use them as a fallback.

**Make the whole library visible to Auto/Assistant:** only tracks that are playable natively are in the catalog
(device files, streams, and legacy tracks that have already been moved). To move the rest in one go, run
`ppMigrateLibrary()` once from the console (or wire it to a button); it shows a background progress notification.

## What I changed in index.html (20 small edits, script `patch_html.py`)

- `native-bridge.js` loaded before the app, with an inline safety stub if the file is missing.
- `audioEl` / `videoEl` are wrapped by a facade that behaves like the HTML element but drives ExoPlayer.
  `document.getElementById('video-el' | 'audio')` returns the facade so your other `pp-*` scripts keep working.
- `loadTrack` hands the source to `PPNative.setSrc`; the Web Audio graph always takes the real element; its analyser is fed from native FFT.
- Library save/restore understand `nativeUri`; Add files / Add folder use the system pickers.
- Video delay engine and MEMC are off on Android. The filter string the page builds is translated into GPU ops
  (the bridge also watches the SVG sliders, so sharpen/clarity/posterize/duotone changes apply live).
- Snapshot (S / camera button) uses the native surface.
- A glue block after `restoreLibrary()`: `ppAddNative`, `ppQueueNext`, catalog mirror, voice search, hooks, FX provider.

`localStorage.ppNativeEngine = 'off'` forces the old web engine (useful for A/B testing).

## Test checklist (on a device)

1. Play an MP3, lock the screen: notification controls, Next/Previous, and automatic advance should work.
2. Unplug headphones / disconnect Bluetooth: playback pauses. Close the app, press the headset play button: it resumes the last item.
3. Play a large MKV/HEVC file: no dropped frames; rotate, scrub, change speed.
4. Filters: pick each preset, then Posterize, Duotone (change both colours), Sharpen, Clarity and the Adjust sliders; compare with the web version.
5. Add a folder with a few hundred files; restart and they still play.
6. Open a legacy library: first play shows "Moving to device storage".
7. Share an audio file to the app; "Open with" too. Video + Home button enters Picture-in-Picture.
8. Android Auto (Desktop Head Unit): browse Songs/Playlists/Artists, play, skip. Assistant: "play <song> on Press Play".
9. S key / camera button saves a snapshot with the current filter.
10. Export an MP3 conversion: it lands in `Music/Press Play`.

## Known gaps and honest caveats

- **Uncompiled Kotlin** (see above). Most likely trouble: `DefaultRenderersFactory.buildAudioSink` signature, `onPlaybackResumption`
  / `onAddMediaItems` signatures in `PlaybackService.kt`, and the Media3 effect base classes in `FilterEffect.kt`.
- **Filters were validated by compiling the shaders, not by running them on a GPU.** The maths mirrors the page (same order, same
  tables, clarity = `src + 2*slope*(src - blur)`). Saturate/grayscale use Rec.709 luminance and a 17-tap blur approximates the page's
  Gaussian, so expect near-identical, not bit-identical, results. Phones with very few fragment uniforms (old low-end GPUs) could
  reject the 24-op shader; lower `FilterParams.MAX` if so.
- **MEMC (frame interpolation) is still off natively.** Media3's effect pipeline is one frame in, one frame out, so it needs a custom renderer path.
- **Manual video/audio delay slider is not wired natively.** Media3 compensates output latency, including Bluetooth, automatically.
- **Snapshots are at on-screen resolution** (PixelCopy of the surface), not the video's native resolution.
- **Android Auto**: list rows have no artwork (artwork lives in private app storage, which Auto can't read), and the session must be
  reviewed/tested with Google's Desktop Head Unit before Play Store distribution to cars.
- **Catalog only contains natively-playable tracks** (see `ppMigrateLibrary()`).
- **`vocal-separator.js`, `update-options.js`, `manifest.json` were not provided**, so I did not touch them. Wrap long tasks like this for
  a background notification: `PPNative.jobs.run('Splitting vocals', async (progress) => { ...; progress(42, 'Stem 2 of 4'); })`.
- **Launcher shortcuts** (`shortcuts.xml`) currently just open the app.
- `document.getElementById` is overridden on Android so legacy scripts get the facade. Code that passes the facade to DOM APIs
  expecting a real Node (`parent.contains(videoEl)`) would throw; I found none in your file.
- Video fullscreen via the HTML Fullscreen API on `#video-wrap` is untested with the transparent-WebView layout.

## Tests I ran

`bridge-test.js` exercises `native-bridge.js` in jsdom against fake `PPPlayer`/`PPLibrary` plugins (48 assertions): event ordering and
`e.target`, stale-snapshot filtering, local pause vs late native state, seek/rate/volume forwarding, native auto-advance and adoption without
reload, legacy-blob chunked migration with size verification, fallback to the web element, the filter-chain parser (order, identity pruning,
posterize/duotone/sharpen/clarity read from the page's SVG, live slider changes, de-duplication), Android Auto/Assistant hand-off (external
start, cold adoption, unexpected advance), catalog push, and the plain-browser path. All pass.
