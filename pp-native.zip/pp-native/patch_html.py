import re, sys
src = open('/mnt/user-data/uploads/index-1.html', encoding='utf-8').read()
s = src
log = []

def rep(old, new, count=1, label=None):
    global s
    n = s.count(old)
    assert n == count, f"[{label or old[:60]!r}] expected {count} match(es), found {n}"
    s = s.replace(old, new)
    log.append(label or old[:50])

# 1. bridge script before the main app script (lamejs tag precedes the main <script>)
rep('<script src="https://cdnjs.cloudflare.com/ajax/libs/lamejs/1.2.1/lame.min.js"></script>',
    '<script src="native-bridge.js"></script>\n<script>/* safety net: if native-bridge.js is missing, run exactly as the plain web app */if(!window.PPNative){window.PPNative={available:false,enabled:false,hooks:{},lib:null,wrapMedia:function(e){return e},setSrc:function(e,t){e.src=t.url;return Promise.resolve()},raw:function(e){return e},active:function(){return false},videoActive:function(){return false},decorateAnalyser:function(){},queueNext:function(){},updateMeta:function(){},setFxProvider:function(){},setVideoFilterCss:function(){},boot:function(){return Promise.resolve()},sameUri:function(){return false},expectAdvance:function(){}};}</script>\n<script src="https://cdnjs.cloudflare.com/ajax/libs/lamejs/1.2.1/lame.min.js"></script>',
    label='bridge script tag')

# 2. media elements become facades on Android (identity in a browser)
rep("const audioEl = document.getElementById('audio');",
    "const audioEl = PPNative.wrapMedia(document.getElementById('audio'), 'audio');", label='audioEl wrap')
rep("  const videoEl = document.getElementById('video-el');\n  const fileInput",
    "  const videoEl = PPNative.wrapMedia(document.getElementById('video-el'), 'video');\n  const fileInput", count=1, label='videoEl wrap') if "  const videoEl = document.getElementById('video-el');\n  const fileInput" in s else None
if 'PPNative.wrapMedia(document.getElementById(\'video-el\')' not in s:
    # videoEl line is not directly followed by fileInput; replace the first occurrence only
    i = s.index("const videoEl = document.getElementById('video-el');")
    s = s[:i] + "const videoEl = PPNative.wrapMedia(document.getElementById('video-el'), 'video');" + s[i+len("const videoEl = document.getElementById('video-el');"):]
    log.append('videoEl wrap (first occurrence)')

# 3. loadTrack hands the source to the bridge
rep("      ppApplyCors(videoEl, t);\n      videoEl.src = t.url;", "      ppApplyCors(videoEl, t);\n      PPNative.setSrc(videoEl, t);", label='loadTrack video src')
rep("      ppApplyCors(audioEl, t);\n      audioEl.src = t.url;", "      ppApplyCors(audioEl, t);\n      PPNative.setSrc(audioEl, t);", label='loadTrack audio src')

# 4. Web Audio graph: always source from the real element; drive the visualizer from native FFT
rep("    const source = ctx.createMediaElementSource(el);", "    const source = ctx.createMediaElementSource(PPNative.raw(el));", label='graph source')
i = s.index("function getGraphFor(kind){")
j = s.index("const analyser = ctx.createAnalyser();", i)
s = s[:j] + "const analyser = ctx.createAnalyser();\n    PPNative.decorateAnalyser(analyser);" + s[j+len("const analyser = ctx.createAnalyser();"):]
log.append('analyser decorate')

# 5. the old "hand video over to a plain <audio> when backgrounded" trick is unnecessary natively
rep("  async function enterBackgroundAudioMode(){\n", "  async function enterBackgroundAudioMode(){\n    if (window.PPNative && PPNative.active()) return;   // native service keeps playing on its own\n", label='bg audio mode')

# 6. library meta + restore
rep("      fileName: t.fileName || null,\n      convertedFromVideo: t.convertedFromVideo || false,",
    "      fileName: t.fileName || null,\n      nativeUri: t.nativeUri || null, nativeArt: t.nativeArt || null, nativeLocal: t.nativeLocal || false, album: t.album || undefined,\n      convertedFromVideo: t.convertedFromVideo || false,", label='saveLibraryMeta')
rep("        const blob = await dbGet(m.dbId);\n        if (!blob) continue; // bytes missing (cleared storage, etc.), skip silently",
"""        if (m.nativeUri){   // lives on the device (SAF reference or app storage), no IndexedDB copy
          let artUrl = null;
          if (m.nativeArt && window.PPNative && PPNative.lib) artUrl = PPNative.lib.fileSrc(m.nativeArt);
          else if (m.artDbId){ const ab = await dbGet(m.artDbId); if (ab) artUrl = URL.createObjectURL(ab); }
          tracks.push({ dbId: m.dbId, artDbId: m.artDbId || null, url: (window.Capacitor && Capacitor.convertFileSrc) ? Capacitor.convertFileSrc(m.nativeUri) : '',
            nativeUri: m.nativeUri, nativeArt: m.nativeArt || null, nativeLocal: !!m.nativeLocal, album: m.album || '', artUrl,
            kind: m.kind, ext: m.ext || 'mp4', title: m.title, artist: m.artist, duration: m.duration, size: m.size != null ? m.size : null,
            width: m.width || null, height: m.height || null, playlistIds: Array.isArray(m.playlistIds) ? m.playlistIds : [], fileName: m.fileName || null,
            stem: m.stem || undefined, stemOf: m.stemOf || null, stemSrc: m.stemSrc || null });
          continue;
        }
        const blob = await dbGet(m.dbId);
        if (!blob) continue; // bytes missing (cleared storage, etc.), skip silently""", label='restoreLibrary native branch')

# 7. removing a track also frees app-storage copies
rep("    dbDelete(removed.dbId).catch(()=>{}).then(refreshStorageEstimate);",
    "    dbDelete(removed.dbId).catch(()=>{}).then(refreshStorageEstimate);\n    if (removed.nativeLocal && window.PPNative && PPNative.lib) PPNative.lib.deleteLocal(removed.nativeUri).catch(()=>{});", label='delete local')

# 8. native pickers (system file/folder chooser, persisted access, no copying)
rep("""  addFilesBtn.addEventListener('click', () => {
    addDropdown.classList.remove('open');
    addBtn.classList.remove('open');
    fileInput.click();
  });
  addFolderBtn.addEventListener('click', () => {
    addDropdown.classList.remove('open');
    addBtn.classList.remove('open');
    folderInput.click();
  });""", """  addFilesBtn.addEventListener('click', () => {
    addDropdown.classList.remove('open');
    addBtn.classList.remove('open');
    if (!ppNativePick('files')) fileInput.click();
  });
  addFolderBtn.addEventListener('click', () => {
    addDropdown.classList.remove('open');
    addBtn.classList.remove('open');
    if (!ppNativePick('folder')) folderInput.click();
  });""", label='picker buttons')

# 9. notification / session metadata follows the app's own metadata updates
rep("    navigator.mediaSession.metadata = new MediaMetadata({\n      title: t.title,",
    "    if (window.PPNative) PPNative.updateMeta(t);\n    navigator.mediaSession.metadata = new MediaMetadata({\n      title: t.title,", label='updateMeta')

# 10. delay engine / MEMC read frames from the <video> element; the native surface has none, and the
#     native renderer already compensates output latency on its own
rep("  function videoDelayActive(){\n", "  function videoDelayActive(){\n    if (window.PPNative && PPNative.enabled) return false;\n", label='delay off natively')
rep("    const want = memcWanted() && memcInitGL();", "    const want = !(window.PPNative && PPNative.enabled) && memcWanted() && memcInitGL();", label='memc off natively')

# 11. colour filters -> GPU effects
rep("    videoEl.style.filter = perfLightActive() ? '' : buildVideoFilterString();\n  }",
    "    videoEl.style.filter = perfLightActive() ? '' : buildVideoFilterString();\n    if (window.PPNative) PPNative.setVideoFilterCss(videoEl.style.filter);\n  }", label='filter -> native')

# 12. closure-level helpers + hook registration, placed right after the library restore kicks off
helpers = r"""
  // ================= Android native engine glue =================
  function ppNativePick(kind){
    if (!(window.PPNative && PPNative.enabled && PPNative.lib)) return false;
    const done = (r) => {
      if (!r || r.cancelled) return;
      if (r.entries) ppAddNative(r.entries, 'pick');
      if (r.tree) ppRememberFolder(r.tree);
    };
    (kind === 'folder' ? PPNative.lib.pickFolder() : PPNative.lib.pickFiles())
      .then(done).catch(e => showToast('Could not add: ' + ((e && e.message) || e), 'error'));
    if (kind === 'folder') showToast('Scanning folder…');
    return true;
  }
  const PP_FOLDERS_KEY = 'ppNativeFolders';
  function ppRememberFolder(tree){
    try {
      const l = JSON.parse(localStorage.getItem(PP_FOLDERS_KEY) || '[]');
      if (l.indexOf(tree) < 0){ l.push(tree); localStorage.setItem(PP_FOLDERS_KEY, JSON.stringify(l)); }
    } catch(e){}
  }
  async function ppRescanFolders(){
    let l = []; try { l = JSON.parse(localStorage.getItem(PP_FOLDERS_KEY) || '[]'); } catch(e){}
    for (const tree of l){
      try { await PPNative.lib.rescan(tree, tracks.map(t => t.nativeUri).filter(Boolean)); } catch(e){}
    }
  }
  async function ppAddNative(entries){
    if (!entries || !entries.length) return;
    const startIdx = tracks.length;
    const targetPlaylistId = userPlaylistViewId();
    const known = new Set(tracks.map(t => t.nativeUri).filter(Boolean));
    const fresh = [];
    for (const e of entries){
      if (!e || !e.uri || known.has(e.uri)) continue;
      known.add(e.uri);
      const kind = e.kind === 'video' ? 'video' : 'audio';
      const track = {
        dbId: 'n_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 8),
        url: (window.Capacitor && Capacitor.convertFileSrc) ? Capacitor.convertFileSrc(e.uri) : '',
        nativeUri: e.uri, nativeArt: e.artPath || null, kind,
        ext: e.ext || (kind === 'video' ? 'mp4' : 'mp3'),
        title: e.title || (e.name || 'Untitled').replace(/\.[^/.]+$/, ''),
        artist: e.artist || (kind === 'video' ? 'Video' : 'Unknown artist'),
        album: e.album || '', duration: e.durationSec || null,
        artUrl: e.artPath ? PPNative.lib.fileSrc(e.artPath) : null, artDbId: null,
        size: e.size >= 0 ? e.size : null, width: e.width || null, height: e.height || null,
        fileName: e.name || null, playlistIds: targetPlaylistId ? [targetPlaylistId] : []
      };
      tracks.push(track);
      fresh.push({ track, e });
    }
    if (!fresh.length) return;
    saveLibraryMeta(); renderPlaylist(); renderPlaylistViewSelect();
    if (currentIndex === -1 && tracks.length > 0) loadTrack(startIdx, false);
    // lyrics / subtitle sidecars sitting next to the media
    const subFiles = [], videoPairs = [];
    for (const { track, e } of fresh){
      for (const sc of (e.sidecars || [])){
        try {
          const r = await PPNative.lib.readText(sc.uri);
          const f = new File([r.text || ''], sc.name, { type: 'text/plain' });
          if (/\.lrc$/i.test(sc.name)) ppSidecarLrc(track, new File([], e.name || ''), [f]);
          else subFiles.push(f);
        } catch(err){}
      }
      if (track.kind === 'video') videoPairs.push({ track, file: new File([], e.name || '') });
    }
    if (subFiles.length) attachSidecarSubtitles(subFiles, videoPairs, fresh.length);
  }
  // What should play after the current track? Mirrors onEnded() so native can advance on its own.
  let ppNextSig = '';
  function ppQueueNext(){
    let n = null;
    try {
      if (currentIndex !== -1 && repeatMode !== 2 && !(sleepTimer && sleepTimer.mode === 'track')){
        const isLast = shuffleOn ? shuffleOrder.indexOf(currentIndex) === shuffleOrder.length - 1 : currentIndex === tracks.length - 1;
        if (!(isLast && repeatMode === 0)){
          const ni = nextTrackIndex();
          if (ni >= 0 && ni !== currentIndex) n = tracks[ni];
        }
      }
    } catch(e){}
    PPNative.queueNext(n);
  }
  if (window.PPNative && PPNative.available){
    PPNative.hooks.getBlob = (t) => dbGet(t.dbId);
    PPNative.hooks.toast = (m, k) => showToast(m, k);
    PPNative.hooks.onMigrated = (t) => { saveLibraryMeta(); dbDelete(t.dbId).catch(()=>{}).then(refreshStorageEstimate); };
    PPNative.hooks.command = (c) => { if (c === 'next') nextBtn.click(); else if (c === 'prev') prevBtn.click(); };
    PPNative.hooks.entries = (list, src) => ppAddNative(list, src);
    PPNative.hooks.syncTo = (uri) => {
      const i = tracks.findIndex(t => PPNative.sameUri(t.nativeUri || t.remoteUrl, uri));
      if (i >= 0 && i !== currentIndex){ PPNative.expectAdvance(uri); loadTrack(i, true); }
    };
    // Native moved on to an item the app would not have picked (e.g. a queue chosen in a car): follow it.
    PPNative.hooks.matchesNext = (uri) => {
      try { const t = tracks[nextTrackIndex()]; return !!t && PPNative.sameUri(t.nativeUri || t.remoteUrl, uri); } catch(e){ return true; }
    };
    // "Hey Google, play <name> on Press Play" / MEDIA_PLAY_FROM_SEARCH
    PPNative.hooks.voiceSearch = (q) => {
      q = String(q || '').toLowerCase().trim();
      if (!q){ if (currentIndex === -1 && tracks.length) loadTrack(0, true); else if (!isPlaying) playBtn.click(); return; }
      const toks = q.split(/\s+/); let best = -1, bestScore = 0;
      tracks.forEach((t, i) => {
        const hay = ((t.title || '') + ' ' + (t.artist || '') + ' ' + (t.album || '')).toLowerCase();
        let sc = 0; toks.forEach(k => { if (hay.indexOf(k) >= 0) sc++; });
        if (sc > bestScore){ bestScore = sc; best = i; }
      });
      if (best >= 0) loadTrack(best, true); else showToast('Nothing matching "' + q + '"');
    };
    // Mirror the library to Android (Auto, Assistant, Bluetooth car kits browse it without the UI)
    let ppCatSig = '', ppCatTimer = 0;
    const ppPushCatalog = () => PPNative.pushCatalog(
      tracks.filter(t => t.nativeUri || t.remoteUrl).map(t => ({
        id: String(t.dbId), uri: t.nativeUri || t.remoteUrl, kind: t.kind, title: t.title || '', artist: t.artist || '',
        album: t.album || '', durMs: t.duration > 0 ? Math.round(t.duration * 1000) : 0, art: t.nativeArt || '', pl: t.playlistIds || []
      })),
      playlists.map(p => ({ id: p.id, name: p.name })));
    const ppCatalogCheck = () => {
      const sig = [tracks.length, playlists.length, playlists.map(p => p.name).join('|'),
        tracks.reduce((a, t) => a + (t.title || '').length + (t.artist || '').length + ((t.nativeUri || t.remoteUrl) ? 1 : 0) + (t.playlistIds || []).length, 0)].join('#');
      if (sig === ppCatSig) return;
      ppCatSig = sig; clearTimeout(ppCatTimer); ppCatTimer = setTimeout(ppPushCatalog, 1500);
    };
    window.ppMigrateLibrary = () => PPNative.migrateAll(tracks);   // run once from the console, or hook to a button
    PPNative.hooks.tick = () => {
      const sig = [currentIndex, shuffleOn, repeatMode, sleepTimer && sleepTimer.mode, tracks.length].join('|');
      if (sig !== ppNextSig){ ppNextSig = sig; ppQueueNext(); }
      ppCatalogCheck();
    };
    PPNative.setFxProvider(() => ({
      eqOn: !!eqEnabled,
      eq: Array.from({ length: 10 }, (_, i) => +eqGains[i] || 0),
      gain: (trackBoostOverrideActive ? trackBoost : masterBoost) * ((typeof rgFactor === 'function' && +rgFactor()) || 1),
      bass: bassBoost, reverb: reverbMix, filter: filterAmount, distortion: distortionAmount,
      bitcrush: bitcrushAmount, echo: echoMix, tremolo: tremoloAmount
    }));
    libP.then(() => { PPNative.boot(); ppRescanFolders(); });
  }
"""
rep("  window.__ppLibReady = libP.then(() => {}, () => {});\n", "  window.__ppLibReady = libP.then(() => {}, () => {});\n" + helpers, label='helpers + hooks')

# 13. exports: save into Music/ or Movies/ via MediaStore before falling back to the share sheet
rep("      const { uri } = await P.Filesystem.getUri({ path, directory: 'CACHE' });\n",
    """      const { uri } = await P.Filesystem.getUri({ path, directory: 'CACHE' });
      if (window.PPNative && PPNative.lib){
        try {
          const kind = /^audio\\//.test(mime) ? 'audio' : /^video\\//.test(mime) ? 'video' : 'other';
          const r = await PPNative.lib.saveToDevice({ path: uri, name: filename, mime, kind });
          if (PPNative.hooks.toast) PPNative.hooks.toast('Saved to ' + (r.location || 'device storage'));
          return true;
        } catch(e){ /* Android 9 or older, or MediaStore refused: use the share sheet below */ }
      }
""", label='saveToDevice')

# 13b. snapshots: the native surface can't be drawn into a canvas, so read it back natively (filters included)
rep("    try{\n      const c=document.createElement('canvas'); c.width=V.videoWidth; c.height=V.videoHeight;",
    "    if(window.PPNative&&PPNative.videoActive()){\n      const t0=((document.getElementById('np-title')||{}).textContent||'snapshot').replace(/[^\\w\\- ]+/g,'').trim().slice(0,60)||'snapshot';\n      PPNative.snapshot().then(b=>{window.ppSaveBlob(b, t0+' '+Math.floor(V.currentTime)+'s.png'); toast('Snapshot saved');}).catch(()=>toast('Snapshot failed.'));\n      return;\n    }\n    try{\n      const c=document.createElement('canvas'); c.width=V.videoWidth; c.height=V.videoHeight;", label='native snapshot')

# 14. CSS: let the native video surface show through the page
css = """
  /* ---- native video surface: the page is see-through above the video box ---- */
  html.pp-native-video #video-wrap{ background:transparent !important; border-radius:0 !important; border-color:transparent !important; }
  html.pp-native-video #video-el{ visibility:hidden; }
  .pp-hole-anc{ background:transparent !important; background-image:none !important; -webkit-backdrop-filter:none !important; backdrop-filter:none !important; }
"""
i = s.index("</style>")
s = s[:i] + css + s[i:]
log.append('css')

open('/home/claude/pp-native/www/index.html', 'w', encoding='utf-8').write(s)
print('\n'.join('ok  ' + l for l in log))
print('size', len(src), '->', len(s))
